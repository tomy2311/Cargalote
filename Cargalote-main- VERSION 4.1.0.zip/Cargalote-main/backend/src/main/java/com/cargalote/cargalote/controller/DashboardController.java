package com.cargalote.cargalote.controller;

import com.cargalote.cargalote.dto.DashboardResumen;
import com.cargalote.cargalote.service.DashboardService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {
    private final DashboardService service;
    public DashboardController(DashboardService service) { this.service = service; }
    @GetMapping("/resumen") public ResponseEntity<DashboardResumen> resumen() {
        return ResponseEntity.ok(service.obtenerResumen());
    }
}
